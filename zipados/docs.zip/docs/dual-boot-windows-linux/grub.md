---
id: grub
title: GRUB
sidebar_label: GRUB
---

Com uma distro do Linux instalada com sucesso, ao reiniciar sua máquina vai se deparar com uma tela semelhante a essa:

![]()

Esse é o GRUB. Aqui você pode selecionar qual Sistema Operacional iniciar.