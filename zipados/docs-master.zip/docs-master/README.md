[![Build Status](https://travis-ci.org/Rocketseat/docs.svg?branch=master)](https://travis-ci.org/Rocketseat/docs)
