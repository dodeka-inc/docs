---
id: help
title: Customize your help page
sidebar_label: Help page
---
The help page is composed by three sections, each of this section returns link to external sources like Twitter, Github etc..

Each section is modify in the `website/pages/help.js` file, they are located in an array `supportsLinks`. Each objects in this array represent one section change the `content` property and the `title` property to customize as you want.

## Currents errors 
> **Note:** Please fell free to add an issue in the [Github repo](https://github.com/luctst/docusaurus-starter-pack) if you have any problem..