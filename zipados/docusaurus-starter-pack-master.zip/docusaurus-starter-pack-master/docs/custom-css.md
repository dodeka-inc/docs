---
id: css
title: Custom CSS
sidebar_label: Add css
---
By default docusaurus already has some CSS properties but you can if you want add your own styles by modifying the `website/static/css/custom.css` file.

## Currents errors 
> **Note:** Please fell free to add an issue in the [Github repo](https://github.com/luctst/docusaurus-starter-pack) if you have any problem..